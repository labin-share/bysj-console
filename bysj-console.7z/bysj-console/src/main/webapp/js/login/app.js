Ext.application({
	name: 'login',
	appFolder:'login',
	views: ['login.view.loginView'],
	launch: function() {
      console.log('aaa');
	}
})